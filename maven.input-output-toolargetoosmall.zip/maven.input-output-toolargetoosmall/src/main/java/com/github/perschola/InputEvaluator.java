package com.github.perschola;

import java.util.Scanner;

public class InputEvaluator {
    final int HIGH_BOUND = 10;

    public void run() {
        Scanner scanner = new Scanner(System.in);

        int guesses = 0;
        // create random number between 1 and n
        // create integer representative of the number of guesses
        int randomNumber = (int) Math.floor(Math.random() * HIGH_BOUND + 1);

        // prompt user to guess number between 1 and n
        // get user input

        // evaluate input from user
        int previousGuess = 0;


        while (true) {
            System.out.println("Guess a number between 1 and " + HIGH_BOUND);
            boolean hasNextInt = scanner.hasNextInt();
            if (hasNextInt) {
                int userGuess = scanner.nextInt();
                if (userGuess > HIGH_BOUND || userGuess < 1) {
                    System.out.println("Guess out of bounds, guess a number between 1 and " + HIGH_BOUND);
                } else if (userGuess == previousGuess) {
                    System.out.println("Guessed that number last time, guess again");
                } else {
                    previousGuess = userGuess;
                    guesses++;
                    if (userGuess == randomNumber) {
                        System.out.println("correct, total guesses " + guesses);
                        break;
                    } else {
                        System.out.println("Too " + (userGuess < randomNumber ? "low" : "high")
                                + " guess again current guesses " + guesses);
                    }
                }
            } else {
                System.out.println("please enter an Integer");
            }


            scanner.nextLine();
        }


        // if input is too low, then
        // display "too low!" to console
        // if input is different from last guess, then
        // increment number of guesses by 1
        // prompt user to re-input value


        // if input is too high, then
        // display "too high!"
        // if input is different from last guess, then
        // increment number of guesses by 1
        // prompt user to re-input value


        // if input is correct value, then
        // display "Correct value!"
        // if input is different from last guess, then
        // increment number of guesses by 1
        // display number of guesses
    }
}