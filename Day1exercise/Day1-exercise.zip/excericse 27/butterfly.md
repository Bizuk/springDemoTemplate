<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>

<h4>LOGO:</h4>
<ul>
  <li>Home</li>
  <li>About
	<ul>
	  <li>Company</li>
	  <li>Patners</li>
	  <li>People</li>
	</ul>
  </li>
  <li>Projects</li>
  <li>Contact</li>
</ul>

<h2>MY PAGE </h2>
<p><strong>YUP!!</strong></p>

<img src="butterfly.jpg" alt="butterfly" width="400"  >

<p>
Butterfly are a beautiful!!!
</p>
<table>
  <tr>
    <th>Morning</th>
    <th>Evening</th>
     <th>Nights</th> 
  </tr>
  <tr> 
    <td>wake up</td>
    <td>Eat</td>
    <td>sleep</td>
  </tr>
  <tr>
    <td> wake up again</td>
    <td> still up</td>
    <td> never mind</td>
  </tr>
    <tr>
    <td> Finally</td>
    <td> on with my day</td>
    <td> sleep</td>
  </tr>
</table>

<p>
No copyRights
</p>
</body>
</html>