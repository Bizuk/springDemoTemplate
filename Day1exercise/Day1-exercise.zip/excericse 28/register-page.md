<html>
<body>
<h4>Login Page</h4>
<form action="">
      First name: <input type="text" placeholder="Enter your First name" name="fname">
	  <br>
      Last name: <input type="text" placeholder="Enter your Last name" name="lname">
      <br>
	  Email: <input type="text" placeholder="Enter your email" name="email">
	  <br>
      Password: <input type="text" placeholder="Enter your password" name="password">
      <br>
	  Confirm Password: <input type="text" placeholder="confirm your password" name="password">
	  <br>
      Password: <input type="text" placeholder="Enter your password" name="password">
      <br>
	  Gender: <input type="radio" name="gender" value="female"> Female
		<input type="radio" name="gender" value="male"> Male
	<br>
	Date of birth: <input type="date" name="bday">
	<br>
	Habits: <input type="checkbox" value="sports" > Sports
	<input type="checkbox" value="sports" > Read
	<input type="checkbox" value="sports" > Cooking
	<br>
	  <button type="submit">Register</button>
    </form>

</body>
</html>