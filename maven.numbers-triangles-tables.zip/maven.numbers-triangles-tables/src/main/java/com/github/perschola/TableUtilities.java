package com.github.perschola;



public class TableUtilities {

    public static void main(String[] args) {
        System.out.println(getMultiplicationTable(20));
    }

    public static String getSmallMultiplicationTable() {
        return getMultiplicationTable(5);
    }

    public static String getLargeMultiplicationTable() {
        return getMultiplicationTable(10);
    }

    public static String getMultiplicationTable(int tableSize) {
        String result = "";
        int digitOfLargest = Math.max(getDigits(tableSize * tableSize), 3);
        for (int row = 1; row <= tableSize; row++) {
            for (int col = 1; col <= tableSize; col++) {
                String cell = "";
                int number = row * col;
//                int digits = getDigits(number);
//                for(int i=0; i<digitOfLargest-digits; i++){
//                    cell += " ";
//                }
                cell = String.format("%" + digitOfLargest + "s", number);
//                cell += number;
                cell += " |";
                result += cell;
            }
            result += "\n";
        }

        return result;
    }

    private static int getDigits(int n) {
        int digits = 0;
        while (n > 0) {
            digits++;
            n /= 10;
        }
        return digits;

    }
}