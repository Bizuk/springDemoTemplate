package com.github.perschola;

public class MainApplication {
    public static void main(String[] args) {
    }
}
