 // Part 2 - Printing line
 function getLine(length) {
    // TODO - write method definition here
     var i = 0;
     var str = "";
     while (i < length) {    
         str  += "*";
         i++  ;
     }
     return str;
}
 // Part 3 - Printing box
 function getBox(width, height) {
    // TODO - write method definition here
     var str = "";
     for (var i = 0; i < height; i++  ) {      
         for (var j = 0; j < width; j++  ) {   
             if (j == width - 1) {           
                 str  += "* \n";              
             } else {                        
                 str += "*";                 
             }
         }
     }
     return str;
}
// PART 4

function getBottomLeftTriangle(length) {
    // TODO - write method definition here
     var str = "";
     for (var i = 1; i <= length; i++  ) {     
         for (var j = 1; j <= i; j++ ) {      
             str  += "*";
         }
         str  += "\n";
     }
     return str;
}

// PART 5
 function getUpperLeftTriangle(length) {
    // TODO - write method definition here
     var str = "";
     for (var i = 1; i <= length; i++  ) {         
         for (var j = length - i; j >= 0; j--) { 
             str  += "*";
         }
         str  += "\n";
     }
     return str;
}
// PART 6
function getPyramid(length) {
    // TODO - write method definition here
     var str = "";
     for (var i = 1; i <= length; i++  ) {             
         for (var k = 1; k <= (length - i); k++  ) {   
             str  += " ";                             
         }
         for (var j = 1; j <= (2*i - 1); j++  ) {        
             str  += "*";                             
         }
         str  += "\n";
     }
     return str;
}
// Part 7 - Checkerboard
 function getCheckerboard(width, height) {
    // TODO - write method definition here
     var str = "";
     for (var i = 0; i < height; i++  ) {           
         for (var j = 0; j < width; j++  ) {
             if ((i +  j) % 2 == 0) {               
                 str  += " ";
             } else {
                 str  += "*";
             }
         }
         str  += "\n";
     }
     return str;
}