package com.github.perschola;

import java.util.Scanner;

public class InputEvaluator {
    public void run() {
        // prompt user to input number
        // get user input
        // create sum variable

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("input a positive integer to get te sum of all values between 1 and the number");
            boolean hasNextInt = scanner.hasNextInt();
            if (hasNextInt) {
                int input = scanner.nextInt();
                if (input > 0) {
                    System.out.println(getOneToNSum(input));
                    break;
                } else {
                    System.out.println("Integer must be greater than 0");
                }
            } else {
                System.out.println("Please Enter an Integer");
            }
            scanner.nextLine();
        }


        // create counter variable
        // evaluate input from user
        // add counter to sum
        // increment counter by 1

        // display sum to user
    }

    private int getOneToNSum(int n) {
        int sum = 0;

        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}