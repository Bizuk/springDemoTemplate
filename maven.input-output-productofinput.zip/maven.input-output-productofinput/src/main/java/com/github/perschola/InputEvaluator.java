package com.github.perschola;
import javax.swing.*;

public class InputEvaluator {
    public void run() {
        // prompt user to input number
        // get user input
        // create product variable
        String product = getUserInput("Please input number:\n");
        Integer productF = Integer.parseInt(product);
        Integer tempNum = productF;
        // create counter variable
        Integer counter = 1;
        while (counter != tempNum){
            // evaluate input from user
            // multiply counter by product
            // increment counter by 1
            productF = counter * productF;
            counter++;
        }
        // display product to user
        product = Integer.toString(productF);
        JOptionPane.showMessageDialog(null,product);
    }

    private String getUserInput(String prompt) {
        return JOptionPane.showInputDialog(
                null,
                prompt,
                "User prompt",
                0);
    }
}