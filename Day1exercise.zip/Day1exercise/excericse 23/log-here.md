<header>
<a href="#">Log HERE here</a>
<nav>
	<a href="#" id="menu-icon"></a>
	<ul>
		<li><a href="#"class="current">Home</a></li>
		<li><a href="#">About</a></li>
		<li><a href="#" title="PF">Personal Projects</a></li>
		<li><a href="#"> Contact</a></li>
My page

Yep!!

<img src="/wp-content/uploads/flamingo.jpg">


	</ul>
</nav>
</header>

<!---LOGO:
Home
About
Company
Patners
People
Projects
Contact
--->



		