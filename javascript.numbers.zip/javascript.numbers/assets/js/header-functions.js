function testCompute(expectedOutput, numberOfStars) {
    test(expectedOutput, compute, numberOfStars);
}








