function compute(expression) {
    numarr=expression.match(/\d+/g);
    addarr=expression.split(/\d+/g);
    num=new Set();
    orderNumarr=new Array();
    orderAddarr=new Array();
    nan=false;
   for(var i=0;i<addarr.length;i++){
         if(addarr[i]=="*" || addarr[i]=="/"){
             orderAddarr.push(addarr[i]);
             if(!num.has(i-1)){
                 orderNumarr.push(numarr[i-1]);
                 num.add(i-1);
             }
             if(!num.has(i)){
                 if(addarr[i-1]=="-"){
                     numarr[i]*=-1;
                 }
                 orderNumarr.push(numarr[i]);
                 num.add(i);
             } 
             if(!nan && i>1 && !(addarr[i-1]=="*" || addarr[i-1]=="/")){
                 addarr[i-1]=" ";
                 nan=true;
             }
           }
     }
     if(nan){
         orderAddarr.push("+");
     }
     for(var i=0;i<addarr.length;i++){ 
         if(!num.has(0)){
             orderNumarr.push(numarr[0]);
             num.add(0);
         }
         if(addarr[i]=="+" || addarr[i]=="-"){
             orderAddarr.push(addarr[i]);
             if(!num.has(i-1)){
                 orderNumarr.push(numarr[i-1]);
                 num.add(i-1);
             }
             if(!num.has(i)){
                 orderNumarr.push(numarr[i]);
                 num.add(i);
             }
         }
      }
      result=parseInt(orderNumarr[0]);
     for (var i = 0; i < orderAddarr.length; i++) {
         switch(orderAddarr[i]){
             case"*": result*=parseInt(orderNumarr[i+1]);
             break;
             case"/": result/=parseInt(orderNumarr[i+1]);
             break;
             case"-": result-=parseInt(orderNumarr[i+1]);
             break;
             case"+": result+=parseInt(orderNumarr[i+1]);
             break;
         }
         
     }
     return result;
   }