package com.github.curriculeon;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by leon on 12/16/2019.
 */
public class GetLastNameTest {
    //given
    private void test(String expectedLastName) {
        Person person = new Person();
        person.setLastName(expectedLastName);
        System.out.println("Expected Last Name "+expectedLastName);

        // when
        String actualLastName = person.getLastName();
        System.out.println("actual1 "+person.getLastName());
        System.out.println("actual2 "+actualLastName);
        System.out.println("actual3 "+actualLastName);
        // then
        Assert.assertEquals(expectedLastName, actualLastName);
    }

    @Test
    public void test0() {
        test("Kassa");
    }

    @Test
    public void test1() {
        test("Test1");
    }

    @Test
    public void test2() {
        test("Leon");
    }

    @Test
    public void test3() {
        test( "Hunter");
    }
}