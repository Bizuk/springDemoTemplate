package com.github.curriculeon;

public class MyObject implements Runnable {
    public void run() {
        // TODO
    }
}
