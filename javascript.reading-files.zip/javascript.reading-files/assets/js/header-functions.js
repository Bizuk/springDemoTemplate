function testGetSingleFileAsText(expectedOutput, evt) {
    test(expectedOutput, getSingleFileAsText, evt);
}