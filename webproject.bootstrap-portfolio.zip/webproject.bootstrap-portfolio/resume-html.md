
<html>
<title>Buzuayehu Kassa</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-container w3-green">
  <h2>Buzuayehu Kassa</h2>


</body>
</html> 

<p>I am an experienced information technology professional within the quality assurance and developer fields. With over 10 years of experience, I have been promoted to multiple roles within the Children's Hospital of Philadelphia network. My experience and skills ranges in in technical quality assurance of websites to developer roles in Drupal, PHP, little of bit of Java. I received my Bachelor's in Computer Information Systems from DeVry University and have multiple technical and programming experiences.</p>
<p>In an integrative solutions organization, I worked on specific projects including testing scripts, reporting discrepancies in data, and other time-sensitive initiatives, provided quality assurance, checking newly developed processes involving the ISO work group and its projects. I worked independently within established project objectives, consulted supervisors regarding unusual circumstances or problems, and had the ability to achieve progress on several projects running simultaneously.</p>
<p>Within my various roles, I have been tasked to execute QA test scripts, find document and report bugs or data discrepancies and re-test, as required along the <a href="http://chop.edu/" target="_blank">chop.edu</a> site. I also had a continuous role in maintaining and writing test scripts and scenarios. A major part of my role(s) has been to maintain project and portfolio activity and report to leadership for problem-solving solutions.</p>
<p>I work very well in team and individual work environments and truly enjoy being a contributing member to the team. I excel in clear and supportive communication to clients and users and I have a strong work ethic, attention to detail and commitment to excellence has always been a valuable 
contribution in completing requests and taking initiative in my job duties. I am a very open minded and always ready to learn from others.</p>

<p><strong>Education</strong></p>

<p>DeVry University, North Brunswick, NJ - Bachelor of Science in Computer Information Systems February 2005 </p>

<p><strong>SUMMARY </strong></p>
<p><strong>A dedicated worker with excellent human relations skills, superior ability to achieve immediate and long-term goals, ability to execute many projects simultaneously, and proven ability to analyze, plan, manage and motivate. </strong></p>

<p><strong>Bilingual Customer Service Representative</strong></p>
<p>AmeriHealth Caritas Pennsylvania</p>
<p>April 2019 to Current</p>
<p>• Responsible for responding in a timely, professional and courteous manner to all customer (member, provider and other customers) inquiries. </p>
<p>• Duty included inbound and outbound member and/or provider phone calls or correspondence regarding benefit, eligibility or customer issues. </p>
<p>• Make outreach welcome calls to new members and conduct Health Risk Assessment Surveys as needed.  </p>
<p>• Provided member education and assist members with PCP selection and assignments. </p>
<p>• Followed internal processes and procedures to ensure all activities are performed in accordance with departmental and company policies and procedures.<br>
<br><strong>Quality Assurance </strong></p>
<p><strong>Children Hospital of Philadelphia</strong></p>
<p><strong>May 20015 – July 2017</strong></p>
<p>In an integrative solutions organization, I worked on specific projects including testing scripts, reporting discrepancies in data, and other time-sensitive initiatives. Provided quality assurance, checking newly developed processes involving the ISO work group and its projects. Worked independently within established project objectives, consulted supervisors regarding unusual circumstances or problems, and had the ability to achieve progress on several minor projects running simultaneously. Specific duties include:</p>
<p>•Requirements review</p>
<p>•Test Script Preparations </p>
<p>•Reporting and Managing defects</p>
<p>•Providing status reports</p>
<p>•Compiling test data and preparing test reports</p>
<p><strong>Developer II - 2011 – 2015</strong></p>
<p><strong>Children Hospital of Philadelphia</strong></p>
<p>As Drupal Developer I worked with the Marketing team to maintain the chop.edu site and wrote test scenarios using Behat. Specific duties include:</p>
<p>•Enhance and maintained chop.edu using Drupal and PHP codes</p>
<p>•Write specific test scripts and scenarios for the content types, H1, H2 or for any similar tags, and scripts that run the front and back end of the site using Behat.</p>
<p>•Wrote and developed code as needed. Managed the coding, unit testing and quality assurance of web applications.</p>
<p>•I used agile methodology using Redmine as the tool</p>
<p><strong>Cold Fusion Developer I - 2004 – 2011</strong></p>
<p><strong>Children Hospital of Philadelphia</strong></p>
<p>As a ColdFusion developer I worked with the Web Team, as part of the organization tasked with running CHOP's internet and intranet sites as well as building internal web applications and maintaining applications. Specific duties include: </p>
<p>•Designed and developed various small applications for use across both the internet and intranet.</p>
<p>•Designed and developed critical clinical applications for study requests</p>
<p>• Continually designed and developed applications per needs of internal customers for the Internet and Intranet sites.</p>
<p>• I have also done some testing and wrote test scripts.</p>
<p>• I used service one to track and report projects.</p>