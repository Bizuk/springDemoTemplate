package com.github.perschola;

import java.util.Scanner;

public class InputEvaluator {
    public void run() {
        // prompt user to input name
        System.out.println("Please input your name");
        // get name input from user
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        if("alice".toLowerCase().equals(input.toLowerCase())){
            System.out.println("Welcome, Alice!");
        } else if("bob".toLowerCase().equals(input.toLowerCase())){
            System.out.println("Welcome, Bob!");
        } else {
            System.out.println("Stranger danger!");
        }

        scanner.close();

        // evaluate name input from user
        // if name is not "Alice" nor "Bob"
        // display "Stranger danger!" to console
        // if name is "Alice"
        // display "Welcome, Alice!"
        // if name is "Bob"
        // display "Welcome, Bob!"
    }
}